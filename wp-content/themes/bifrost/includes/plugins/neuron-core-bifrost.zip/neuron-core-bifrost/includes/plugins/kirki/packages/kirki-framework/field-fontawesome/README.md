# control-fontawesome

## Installation

First, install the package using composer:

```bash
composer require kirki-framework/field-fontawesome
```

Make sure you include the autoloader:
```php
require_once get_parent_theme_file_path( 'vendor/autoload.php' );
```

This field creates a dropdown containing all names for the font-awesome v4.7
