# googlefonts
A simple package containing JSON files for all googlefonts.

To update the fonts run
```
npm install && grunt
```